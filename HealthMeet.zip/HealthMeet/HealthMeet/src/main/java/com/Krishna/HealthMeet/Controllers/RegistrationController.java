package com.Krishna.HealthMeet.Controllers;


import com.Krishna.HealthMeet.Entity.Customer;
import com.Krishna.HealthMeet.repository.CustomerRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequiredArgsConstructor
public class RegistrationController {
    private final CustomerRepository customerRepository;
    private final PasswordEncoder passwordEncoder;
    @PostMapping("/register")
    public ResponseEntity<String> register(@RequestBody Customer customer) {
        try {


            String hashPwd = passwordEncoder.encode(customer.getPassword());
            customer.setPassword(hashPwd);
            Customer savedCustomer = customerRepository.save(customer);

            if (savedCustomer.getId() > 0) {
                return ResponseEntity.status(HttpStatus.CREATED).
                        body("Given user details are successfully registered");
            } else {
                return ResponseEntity.status(HttpStatus.BAD_REQUEST).
                        body("User registration failed");
            }
        } catch (Exception ex) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).
                    body("An exception occurred: " + ex.getMessage());

        }
    }
        @PostMapping("/registerdoctor")
        @PreAuthorize("hasRole('ADMIN')")
        public ResponseEntity<String> doctorRegister(@RequestBody Customer customer){
            try {


                String hashPwd = passwordEncoder.encode(customer.getPassword());
                customer.setPassword(hashPwd);
                Customer savedCustomer = customerRepository.save(customer);

                if (savedCustomer.getId() > 0) {
                    return ResponseEntity.status(HttpStatus.CREATED).
                            body("Given user details are successfully registered");
                } else {
                    return ResponseEntity.status(HttpStatus.BAD_REQUEST).
                            body("User registration failed");
                }
            } catch (Exception ex) {
                return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).
                        body("An exception occurred: " + ex.getMessage());

            }
        }





}
