package com.Krishna.HealthMeet;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HealthMeetApplicationTests {

	@Test
	void contextLoads() {
	}

}
